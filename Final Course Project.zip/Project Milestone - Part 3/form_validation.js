        $(document).ready(function() {
            $('#signup').validate({
                rules: {
                    name: {
                        required: true
                    },
                    email: {
                        required: true,
                        email: true
                    }
                }, //end rules
                messages: {
                    name: {
                        required: "Please supply your name."
                    },
                    email: {
                        required: "Please supply an e-mail address.",
                        email: "This is not a valid email address."
                    }
                },
                errorPlacement: function(error, element) {
                    if (element.is(":radio") || element.is(":checkbox")) {
                        error.appendTo(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                }

            }); // end validate 
        }); // end ready