console.log("Script loaded!");


document.addEventListener('DOMContentLoaded', function () {
    const navBarToggle = document.getElementById('js-navbar-toggle');
    const mainNav = document.querySelector('.navbar ul');

    navBarToggle.addEventListener('click', function () {
        mainNav.classList.toggle('active');
    });


    const titlesDropdown = document.getElementById("titles-dropdown");
    const titlesSubmenu = document.getElementById("titles-submenu");

    titlesDropdown.addEventListener("mouseenter", function () {
        titlesSubmenu.style.display = "block";
    });

    titlesDropdown.addEventListener("mouseleave", function () {
        titlesSubmenu.style.display = "none";
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const mainNav = document.querySelector('.navbar ul');
    mainNav.classList.add('hidden');
});

window.addEventListener('resize', function () {
    const navBarToggle = document.getElementById('js-navbar-toggle');
    const mainNav = document.querySelector('.navbar ul');

    if (window.innerWidth <= 600) {
        mainNav.classList.add('hidden');
        navBarToggle.classList.remove('hidden');
    } else {
        mainNav.classList.remove('hidden');
        navBarToggle.classList.add('hidden');
    }
});

window.addEventListener('load', function () {
    const navBarToggle = document.getElementById('js-navbar-toggle');
    const mainNav = document.querySelector('.navbar ul');

    if (window.innerWidth <= 600) {
        mainNav.classList.add('hidden');
        navBarToggle.classList.remove('hidden');
    } else {
        mainNav.classList.remove('hidden');
        navBarToggle.classList.add('hidden');
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const accordionContainers = document.querySelectorAll('.accordion-container');

    accordionContainers.forEach(function (container) {
        const accordion = container.querySelector('.accordion');
        const toggleAccordion = container.querySelector('.toggle-accordion');

        toggleAccordion.addEventListener('click', function () {
            accordion.classList.toggle('active');

            if (accordion.style.maxHeight) {
                accordion.style.maxHeight = null;
            } else {
                // Collapse the old one
                accordionContainers.forEach(function (otherContainer) {
                    const otherAccordion = otherContainer.querySelector('.accordion');
                    if (otherAccordion !== accordion && otherAccordion.classList.contains('active')) {
                        otherAccordion.classList.remove('active');
                        otherAccordion.style.maxHeight = null;
                    }
                });

                // Expand the clicked one
                accordion.style.maxHeight = accordion.scrollHeight + 'px';
            }
        });
    });
});
